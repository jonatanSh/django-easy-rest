from django.apps import AppConfig


class DjangoEasyRestConfig(AppConfig):
    name = 'easy_rest'
